// WRITE YOUR CODE HERE
$("#div1").click(function() {
   $("#div2").text("You Nailed it!! Best of Luck!!");
   $("#div2").css("display", "block");
   $("#div1").addClass("highlight");
});