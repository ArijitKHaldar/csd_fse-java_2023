//WRITE YOUR CODE HERE
$("button").click(function() {
    const text = $("textarea").val();
    if(text.length <= 50)
        $("#msg").text('The length of the entered text is:' + text.length);
    else
        $("#msg").text('Sorry!! Text length exceeds the limit');
});