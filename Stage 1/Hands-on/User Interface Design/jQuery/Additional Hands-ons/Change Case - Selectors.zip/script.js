// WRITE YOUR CODE HERE
$("#btn").click(function() {
   var text = $("#txt1").val();
   var textUpper = text.toUpperCase();
   var textLower = text.toLowerCase();
   
   if(text === textUpper)
       $("#txt1").val(text.toLowerCase());
   else if(text === textLower)
       $("#txt1").val(text.toUpperCase());
   else {
       var newtext = [];
       for (var ch =0; ch < text.length; ch++) {
           if (text[ch] === text[ch].toUpperCase())
               newtext[ch] = text[ch].toLowerCase();
           else
               newtext[ch] = text[ch].toUpperCase();
       }
       $("#txt1").val(newtext.join(""));
   }
});