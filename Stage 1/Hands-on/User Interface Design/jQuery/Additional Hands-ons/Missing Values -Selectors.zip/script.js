 // WRITE YOUR CODE HERE
 $("table td").each(function() {
     var cellText = $(this).html();
     if(cellText === "") {
        $(this).html('Missing Value');
        $(this).css("background-color", "yellow");
     }
 });