// WRITE YOUR CODE HERE
$("#btn").click(function() {
   const num = $("#input_no").val();
   $("span.jelly_no").text(num);
});