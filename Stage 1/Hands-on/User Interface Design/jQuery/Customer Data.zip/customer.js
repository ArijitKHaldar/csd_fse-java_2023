//WRITE YOUR jQUERY CODE HERE
$("input[type='button']").click(function() {
    const name = $("#name").val();
    $("table tr:last").after('<tr><td><input type = "checkbox" name = "record"></td>' + name + '</td></tr>');
});

$("button").click(function() {
    $("table input:checkbox").each(function() {
        if (this.checked) {
            $(this).closest('tr').remove();
        }
    });
});