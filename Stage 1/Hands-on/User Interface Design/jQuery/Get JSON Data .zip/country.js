//WRITE YOUR jQUERY CODE HERE
$("#btn-id").click(function() {
    $.getJSON("https://reqres.in/api/users?page=2", function(data) {
        var list = $("<ul></ul>").appendTo("#data-id");
        data.forEach(function() {
            list.append("<li>" + element.id + "--" + element.email + "</li>");
        });
    });
});