//WRITE YOUR jQUERY CODE HERE
$(function() {
    var chkboxes = function() {
        var n=$('input:checked').length;
        $("#result").text(n+(n===1?' box is':' boxes are')+' checked');
    }
    //This is executed to show the 0 checkboxes condition
    chkboxes();
    //Now this compiles all the clicks on the checkboxes
    $("input[type=checkbox]").on("click",chkboxes);
});