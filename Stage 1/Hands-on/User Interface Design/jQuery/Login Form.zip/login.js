//WRITE YOUR JQUERY CODE HERE
$('#login').addClass("btn btn-info");
$('#signup').addClass("btn btn-info");
$('#submit').addClass("btn btn-primary");
$('input[type="reset"]').addClass("btn btn-primary");
$('#signup_div').hide();
$('#signup').click(function() {
    $('#signup_div').show();
});