//WRITE YOUR jQUERY CODE HERE
$("#each_ex").click(function() {
    $("#msg_ex").append("<br>");
    $("ul[id='list'] li").clone().appendTo("#msg_ex");
    $("#msg_ex li").css("list-style-type", "none");
    $("ul[id='list'] li a").css("background-color","red");
});