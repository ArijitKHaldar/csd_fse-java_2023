SELECT Student.student_name, Department.department_name 
FROM Student, Department 
WHERE STUDENT.city = "Coimbatore"
AND Student.department_id = Department.department_id
ORDER BY Student.student_name;