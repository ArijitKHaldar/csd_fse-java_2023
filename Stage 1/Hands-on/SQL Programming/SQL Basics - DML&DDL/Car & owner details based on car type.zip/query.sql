SELECT car_id, car_name, owner_id FROM cars
WHERE car_type IN("Hatchback","SUV")
ORDER BY car_id;